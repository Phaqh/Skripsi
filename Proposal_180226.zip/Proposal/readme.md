# Proposal
proceed with caution
## todos
- [ ] check bab1 allignment with current idea
- [ ] check bab2 allignment with current idea
- [ ] check bab3 allignment with current idea
- [ ] add bab1 citations
- [ ] add bab2 citations
- [ ] add bab3 citations
- [ ] write bab 4 with new LSTM
- [ ] Last Check on model

